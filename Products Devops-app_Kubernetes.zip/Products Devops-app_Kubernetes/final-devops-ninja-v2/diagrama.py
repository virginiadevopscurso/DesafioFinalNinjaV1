from diagrams import Diagram, Cluster

from diagrams.k8s.compute import Pod, Deployment,ReplicaSet
from diagrams.k8s.network import SVC, Ing
from diagrams.k8s.storage import PV, PVC, Vol
from diagrams.k8s.group import Namespace


with Diagram("k8s Architecture", show=False):

    fe_ing = Ing("devops.ip.nip.io")

    with Cluster("aws-eks"):

        nm = Namespace("monorepo")

        # Services
        fe_svc = SVC("ms-frontend")
        be_svc = SVC("products")
        ms_svc = SVC("shopping-cart")
        
        # Pods
        fe_pod = Pod("")
        be_pod = Pod("")
        ms_pod = Pod("")
        #Deployment
        fe_deploy = Deployment("frontend-deploy")
        be_deploy = Deployment("products-deploy")
        ms_deploy = Deployment("shopping-cart-deploy") 
        #Replicaset
        fe_rs = ReplicaSet("")
        be_rs = ReplicaSet("")
        ms_rs = ReplicaSet("") 
        
    fe_ing >> fe_svc
    fe_svc >> fe_pod
    be_svc >> be_pod
    be_svc >> fe_deploy
    ms_svc >> ms_pod
    ms_svc >> fe_deploy
    fe_pod >> fe_rs
    fe_rs >> fe_deploy
    be_pod >> be_rs
    be_rs >> be_deploy
    ms_pod >> ms_rs
    ms_rs >> ms_deploy